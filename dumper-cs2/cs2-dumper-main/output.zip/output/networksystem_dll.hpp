// Generated using https://github.com/a2x/cs2-dumper
// 2026-05-22 21:00:25.760070800 UTC

#pragma once

#include <cstddef>
#include <cstdint>

namespace cs2_dumper {
    namespace schemas {
        // Module: networksystem.dll
        // Class count: 1
        // Enum count: 0
        namespace networksystem_dll {
            // Parent: None
            // Field count: 1
            namespace ChangeAccessorFieldPathIndex_t {
                constexpr std::ptrdiff_t m_Value = 0x0; // int32
            }
        }
    }
}
